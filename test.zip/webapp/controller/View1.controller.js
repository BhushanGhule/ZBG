sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/Filter"], function(Controller, Filter) {
	"use strict";
	return Controller.extend("testtest.controller.View1", {
		/**
		 *@memberOf testtest.controller.View1
		 */
		onSuggest: function(oEvent) {

			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = [];
			if (sTerm) {
				aFilters.push(new Filter("Name", sap.ui.model.FilterOperator.StartsWith, sTerm));
			}
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);

		}
	});
});