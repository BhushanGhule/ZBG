sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"
], function(Controller, JSONModel, MessageBox) {
	"use strict";
	return Controller.extend("Customer.controller.View1", {
		/**
		 *@memberOf Customer.controller.View1
		 */
		onHelpCountry: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			oModel.read("/CountrySet()", {
				success: function(oData, oResponse) {
					var oInput = this.getView().byId("icountry");
					var oText = this.getView().byId("tcountry");
					if (!this._oValueHelpDialog1) {
						this._oValueHelpDialog1 = new sap.ui.comp.valuehelpdialog.ValueHelpDialog("idValueHelp1", {
							key: "Land1",
							descriptionKey: "Landx50",
							supportMultiselect: false,
							filterMode: true,
							ok: function(oEvent) {
								var aTokens = oEvent.getParameter("tokens");
								oInput.setValue(aTokens[0].getKey());
								oText.setText(aTokens[0].getText());
								this.close();
								this._oValueHelpDialog1.destroy();
							},
							cancel: function() {
								this.close();
								this._oValueHelpDialog1.destroy();
							}
						});
					}
					var oColModel = new sap.ui.model.json.JSONModel();
					oColModel.setData({
						cols: [{
							label: "Country",
							template: "Land1"
						}, {
							label: "Country Text",
							template: "Landx50"
						}]
					});
					var oTable = this._oValueHelpDialog1.getTable();
					oTable.setModel(oColModel, "columns");
					var oRowModel = new JSONModel(oData.results);
					oTable.setModel(oRowModel);
					oTable.bindRows("/");
					this._oValueHelpDialog1.open();
				}.bind(this),
				error: function(oError) {}.bind(this)
			});
		},
		onHelpCurrency: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			oModel.read("/CurrencySet()", {
				success: function(oData, oResponse) {
					var oInput = this.getView().byId("icurrency");
					var oText = this.getView().byId("tcurrency");
					if (!this._oValueHelpDialog2) {
						this._oValueHelpDialog2 = new sap.ui.comp.valuehelpdialog.ValueHelpDialog("idValueHelp2", {
							key: "Waers",
							descriptionKey: "Ltext",
							supportMultiselect: false,
							filterMode: true,
							ok: function(oEvent) {
								var aTokens = oEvent.getParameter("tokens");
								oInput.setValue(aTokens[0].getKey());
								oText.setText(aTokens[0].getText());
								this.close();
								this._oValueHelpDialog2.destroy();
							},
							cancel: function() {
								this.close();
								this._oValueHelpDialog2.destroy();
							}
						});
					}
					var oColModel = new sap.ui.model.json.JSONModel();
					oColModel.setData({
						cols: [{
							label: "Currency",
							template: "Waers"
						}, {
							label: "Currency Text",
							template: "Ltext"
						}, {
							label: "Currency",
							template: "Ktext"
						}]
					});
					var oTable = this._oValueHelpDialog2.getTable();
					oTable.setModel(oColModel, "columns");
					var oRowModel = new JSONModel(oData.results);
					oTable.setModel(oRowModel);
					oTable.bindRows("/");
					this._oValueHelpDialog2.open();
				}.bind(this),
				error: function(oError) {}.bind(this)
			});
		},
		/**
		 *@memberOf Customer.controller.View1
		 */
		createCustomer: function(oEvent) {
			if (this.formValidate() == "X") {

				var oCustomer = {};
				// oCustomer.Customer   =  
				oCustomer.FirstName = this.getView().byId("icustomerName").getValue();
				oCustomer.LastName = this.getView().byId("ilastName").getValue();
				oCustomer.Dob = new Date(this.getView().byId("idob").getValue());
				oCustomer.Email = this.getView().byId("iemail").getValue();
				oCustomer.Address1 = this.getView().byId("iaddress1").getValue();
				oCustomer.Address2 = this.getView().byId("iaddress2").getValue();
				oCustomer.Pin = this.getView().byId("ipin").getValue();
				oCustomer.Country = this.getView().byId("icountry").getValue();
				oCustomer.Currency = this.getView().byId("icurrency").getValue();

				var oModel = this.getOwnerComponent().getModel();
				var customerHeader = {
					"Content-Type": "application/atom+xml;type=entry; charset=utf-8"
				};
				oModel.setHeaders(customerHeader);

				oModel.create("/CUSTOMERSet", oCustomer, {

					success: function(oData, oResponse) {
						alert("sucess");
                        this.getView().byId("Save").setVisible(false);
						var simpleForm = this.getView().byId("simpleForm").getContent();
						var formLength = simpleForm.length;
						for (var count = 0; count < formLength; count++) {
							if (simpleForm[count].setEnabled !== undefined) {
								simpleForm[count].setEnabled(false);
							}
						}
					}.bind(this),
					error: function(oData, oResponse) {
						alert("Error");
					}.bind(this)
				});

			}
		},

		clearForm: function(oEvent) {
            this.getView().byId("tcurrency").setText(""); 
            this.getView().byId("tcountry").setText(""); 
			var simpleForm = this.getView().byId("simpleForm").getContent();
			var formLength = simpleForm.length;
			for (var count = 0; count < formLength; count++) {
				if (simpleForm[count].setValue !== undefined) {
					simpleForm[count].setValue("");
				}
			}

		},

		formValidate: function(noError) {

			var simpleForm = this.getView().byId("simpleForm").getContent();
			var formLength = simpleForm.length;
			for (var count = 0; count < formLength; count++) {
				if (simpleForm[count].setValueState !== undefined) {
					simpleForm[count].setValueState(sap.ui.core.ValueState.None);
				}
			}

			if (this.getView().byId("icustomerName").getValue() === "") {
				this.getView().byId("icustomerName").focus();
				this.getView().byId("icustomerName").setValueState(sap.ui.core.ValueState.Error);
				this.errorMessage("Please enter First Name");
			} else if (this.getView().byId("ilastName").getValue() === "") {
				this.getView().byId("ilastName").focus();
				this.getView().byId("ilastName").setValueState(sap.ui.core.ValueState.Error);
				this.errorMessage("Please enter Last Name");
			} else if (this.getView().byId("idob").getValue() === "") {
				this.getView().byId("idob").focus();
				this.getView().byId("idob").setValueState(sap.ui.core.ValueState.Error);
				this.errorMessage("Please enter date of birth");
			} else if (this.getView().byId("iemail").getValue() === "") {
				this.getView().byId("iemail").focus();
				this.getView().byId("iemail").setValueState(sap.ui.core.ValueState.Error);
				this.errorMessage("Please enter email");
			} else if (this.getView().byId("iaddress1").getValue() === "") {
				this.getView().byId("iaddress1").focus();
				this.getView().byId("iaddress1").setValueState(sap.ui.core.ValueState.Error);
				this.errorMessage("Please enter address 1");
			} else if (this.getView().byId("iaddress2").getValue() === "") {
				this.getView().byId("iaddress2").focus();
				this.getView().byId("iaddress2").setValueState(sap.ui.core.ValueState.Error);
				this.errorMessage("Please enter address 2");
			} else if (this.getView().byId("ipin").getValue() === "") {
				this.getView().byId("ipin").focus();
				this.getView().byId("ipin").setValueState(sap.ui.core.ValueState.Error);
				this.errorMessage("Please enter PIN code");
			} else if (this.getView().byId("icountry").getValue() === "") {
				this.getView().byId("icountry").focus();
				this.getView().byId("icountry").setValueState(sap.ui.core.ValueState.Error);
				this.errorMessage("Please enter country");
			} else if (this.getView().byId("icurrency").getValue() === "") {
				this.getView().byId("icurrency").focus();
				this.getView().byId("icurrency").setValueState(sap.ui.core.ValueState.Error);
				this.errorMessage("Please enter currency");
			} else {
				noError = "X";
			}
			return noError;
		},

		errorMessage: function(message) {

			MessageBox.show(message, {
				icon: sap.m.MessageBox.Icon.ERROR,
				title: "Error Occured"
			});

		}

	});
});