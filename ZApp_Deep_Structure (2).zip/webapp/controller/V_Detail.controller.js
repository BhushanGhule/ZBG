sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("ZApp_Deep_Structure.controller.V_Detail", {

		onAdd: function() {
			// Get the values of the header input fields
			var ComCode = this.getView().byId("inputCC").getValue();
			var Plant = this.getView().byId("inputPlant").getValue();
			if (ComCode == "" && Plant == "") {
				alert("Company Code and Plant cannot be blank");
			}

			// Get the values of the input fields.
			var mat = this.getView().byId("inMaterial").getValue();
			var bat = this.getView().byId("inBatch").getValue();
			var qty = this.getView().byId("inQty").getValue();
			var uom = this.getView().byId("inUOM").getValue();
			if (mat != "" && bat != "" && qty != "" && uom != "") {} else {
				// alert("Material/Batch/Quantity/UOM cannot be blank");

				// Push this entry into array and bind it to the table
				var itemRow = {
					Material: mat,
					Batch: bat,
					Quantity: qty,
					Unit: uom
				};

				var oModel = this.getView().byId("packItem").getModel();
				var itemData = oModel.getProperty("/data");

			};

		},
		onDelete: function() {
			var oTable = this.getView().byId("packItem");
			var oModel2 = oTable.getModel();
			var aRows = oModel2.getData().Sheet1;
			var aContexts = oTable.getSelectedContexts();

			for (var i = aContexts.length - 1; i >= 0; i--) {
				var oThisObj = aContexts[i].getObject();
				var index = $.map(aRows, function(obj, index) {

					if (obj === oThisObj) {
						return index;
					}
				});
				aRows.splice(index, 1);
			}
			// oModel2.setData({
			// 	data: aRows
			// });
			oTable.removeSelections(true);

		},
		onAddRow: function() {

			var oItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						Required: true,
						showSuggestion: true,
						// suggestionItems: "{/Sheet1}",
						width: "200px"
					}),
					new sap.m.Input({
						width: "200px"
					}),
					new sap.m.Input({
						width: "200px"
					}),
					new sap.m.Input({
						width: "200px",
						showValueHelp: true
					}),
					new sap.m.Button({
						text: "Delete",
						press: [this.remove, this]
					})
				]
			});

			var oTable = this.getView().byId("packItem");
			oTable.addItem(oItem);

		},

		remove: function(oEvent) {
			var oTable = this.getView().byId("packItem");
			oTable.removeItem(oEvent.getSource().getParent());
		},

		onSave: function(oEvent) {
			var oTable = this.getView().byId("packItem");

			// Get the table Model
			var oModel = oTable.getModel();

			// Get Items of the Table
			var aItems = oTable.getItems();

			// Define an empty Array
			var itemData = [];

			for (var iRowIndex = 0; iRowIndex < aItems.length; iRowIndex++) {
				// var l_material = oModel.getProperty("Material", aItems[iRowIndex].getBindingContext());
				// var l_batch = oModel.getProperty("Batch", aItems[iRowIndex].getBindingContext());
				// var l_quantity = oModel.getProperty("Quantity", aItems[iRowIndex].getBindingContext());
				// var l_unit = oModel.getProperty("Unit", aItems[iRowIndex].getBindingContext());

				for (var iCellIndex = 0; iCellIndex < aItems[iRowIndex].getCells().length; iCellIndex++) {
					if(iCellIndex=="0"){
					var l_material = aItems[iRowIndex].getCells()[iCellIndex].getValue();
					}else if(iCellIndex=="1"){  
					var l_batch = aItems[iRowIndex].getCells()[iCellIndex].getValue();
					}else if(iCellIndex=="2"){  					
					var l_quantity = aItems[iRowIndex].getCells()[iCellIndex].getValue();
					}else if(iCellIndex=="3"){  
					var l_unit = aItems[iRowIndex].getCells()[iCellIndex].getValue();
					}
				}
				if(l_material != undefined){
					itemData.push({
						Batch: l_batch,
						Matnr: l_material,
						Qty: l_quantity,
						Uom: l_unit,
					});
				}
			}
			// Get the values of the header input fields
			var ComCode = this.getView().byId("inputCC").getValue();
			var Plant = this.getView().byId("inputPlant").getValue();

			// Create one emtpy Object
			var oEntry1 = {};

			oEntry1.Bukrs = ComCode;
			oEntry1.Werks = Plant;

			//Using Deep entity the data is posted as shown below .

			// Link Pack items to the Pack header
			// Very very Important. Here the name should be exactly like the Entity Set at Backend OData
			// Stack_HU_Pack_MatSet is the same name at back end
			oEntry1.Stack_HU_Pack_MatSet = itemData;

		}

	});
});