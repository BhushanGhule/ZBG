sap.ui.controller("SalesList.ext.controller.ListReportExt", {

	onClickActionZCDS_SNWD_SO1: function(oEvent) {
		
		alert("Created by Trigger");
		
	}
});